/* global game, Phaser, playState, menuState, mainMenuState */

var button;

var menuState = {
    
    
    preload: function() { 
        
    },
    
    
    create: function() {
        
    },
    
    
    update: function() {
        
    },

    startGame: function() {
        // game.state.start('play');
    }

};
